
    <?php
    require('Database Connection file/mysqli_connect.php');
    $sql="select * from feedback";
    $result=mysqli_query($dbc,$sql) or die("bad query:$sql");
    echo "<tr><th><h1>Feedback</h1></th></tr>";
    echo "<table>";
    while($row=mysqli_fetch_assoc($result))
    {
            echo"<h3>{$row['feed']}<br>";
    }
    echo "</table>";
    ?>
