<?php
	session_start();
?>
<html>
	<head>
		<title>
			Welcome Administrator
		</title>
		<link rel="stylesheet" type="text/css" href="css/style.css"/>
		<link rel="stylesheet" href="font-awesome-4.7.0\css\font-awesome.min.css">
	</head>
	<body>
	<div class="box">

		
		<h1 id="title">
			PES Airways	</h1>
	
		<div>
			<ul>
				<li><a href="admin_homepage.php"><i class="fa fa-home" aria-hidden="true"></i> Home</a></li>
				<li><a href="admin_homepage.php"><i class="fa fa-desktop" aria-hidden="true"></i> Dashboard</a></li>
				<li><a href="logout_handler.php"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout</a></li>
			</ul>
		</div>
		<h2>Welcome Administrator!</h2>
		
		<center>
		<table cellpadding="5">
			
			<tr>
				<td class="admin_func"><a href="admin_view_booked_tickets.php"><i class="fa fa-plane" aria-hidden="true"></i><b> View List of Booked Tickets for a Flight</a>
				</td>
			</tr>
			<tr>
				<td class="admin_func"><a href="add_flight_details.php"><i class="fa fa-plane" aria-hidden="true"></i><b> Add Flight Schedule Details</a>
				</td>
			</tr>
		
			<tr>
				<td class="admin_func"><a href="delete_flight_details.php"><i class="fa fa-plane" aria-hidden="true"></i><b> Delete Flight Schedule Details</a>
				</td>
			</tr>
			<tr>
				<td class="admin_func"><a href="add_jet_details.php"><i class="fa fa-plane" aria-hidden="true"></i><b> Add Aircrafts Details</a>
				</td>
			</tr>
			<tr>
				<td class="admin_func"><a href="activate_jet_details.php"><i class="fa fa-plane" aria-hidden="true"></i> <b>Activate Aircraft</a>
				</td>
			</tr>
			<tr>
				<td class="admin_func"><a href="deactivate_jet_details.php"><i class="fa fa-plane" aria-hidden="true"></i><b> Deactivate Aircraft</a>
				</td>
			</tr>
			<tr>
				<td class="admin_func"><a href="mail.php"><i class="fa fa-plane" aria-hidden="true"></i><b> Mail </a>
				</td>
			</tr>
			<tr>
				<td class="admin_func"><a href="viewfeedback.php"><i class="fa fa-plane" aria-hidden="true"></i><b> View Feedback</a>
				</td>
			</tr>
		</table>
		
</center>
		</div>
		
	</body>
	<style>
				.box{
				width:100%;
				height:99.7%;
				margin: 1px auto;
				
				background-image:url("images/air.jpg");
				background-size:cover;
				text-align:center;
			}

		td,
th {
    border: 1px solid rgb(190, 190, 190);
    padding: 10px;
}

td {
    text-align: center;
}

tr:nth-child(even) {
    background-color:rgba(0,0,0,.5);
}
tr:nth-child(odd) {
    background-color: rgba(0,0,0,.2);
}

th[scope="col"] {
    background-color: #696969;
    color: #fff;
}

th[scope="row"] {
    background-color: #d7d9f2;
}

	</style>
</html>